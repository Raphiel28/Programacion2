﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class Productos : Form
    {
       public Productos()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult _resp;
            _resp = MessageBox.Show("¿Está seguro que desea salir del programa?", "Saliendo del programa", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2);
            if (_resp == DialogResult.Yes)
                Application.Exit();
        }

        private void btnMin_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void txtNombre_MouseClick(object sender, MouseEventArgs e)
        {
            txtNombre.SelectAll();
        }

        private void txtNombre_MouseLeave(object sender, EventArgs e)
        {
            if (txtNombre.Text == "")
            {
                txtNombre.Text = "Nombre";
                txtNombre.ForeColor = Color.Silver;
            }
            if (txtNombre.Text != "Nombre")
                txtNombre.ForeColor = Color.Black;
        }

        private void txtNombre_Enter(object sender, EventArgs e)
        {
            txtNombre.SelectAll();
        }

        private void txtCodigo_Enter(object sender, EventArgs e)
        {
            txtCodigo.SelectAll();
        }

        private void txtCodigo_MouseClick(object sender, MouseEventArgs e)
        {
            txtCodigo.SelectAll();
        }

        private void txtCodigo_MouseLeave(object sender, EventArgs e)
        {
            if (txtCodigo.Text == "")
            {
                txtCodigo.Text = "Código";
                txtCodigo.ForeColor = Color.Silver;
            }
            if (txtCodigo.Text != "Código")
                txtCodigo.ForeColor = Color.Black;
        }

        private void txtExistencia_MouseClick(object sender, MouseEventArgs e)
        {
            txtExistencia.SelectAll();
        }

        private void txtExistencia_MouseLeave(object sender, EventArgs e)
        {
            if (txtExistencia.Text == "")
            {
                txtExistencia.Text = "Existencia";
                txtExistencia.ForeColor = Color.Silver;
            }
            if (txtExistencia.Text != "Existencia")
                txtExistencia.ForeColor = Color.Black;
        }

        private void txtExistencia_Enter(object sender, EventArgs e)
        {
            txtExistencia.SelectAll();
        }

        private void txtDescripcion_Enter(object sender, EventArgs e)
        {
            txtDescripcion.SelectAll();
        }

        private void txtDescripcion_MouseClick(object sender, MouseEventArgs e)
        {
            txtDescripcion.SelectAll();
        }

        private void txtDescripcion_MouseLeave(object sender, EventArgs e)
        {
            if (txtDescripcion.Text == "")
            {
                txtDescripcion.Text = "Descripción";
                txtDescripcion.ForeColor = Color.Silver;
            }
            if (txtDescripcion.Text != "Descripción")
                txtDescripcion.ForeColor = Color.Black;
        }

        private void txtCategoria_Enter(object sender, EventArgs e)
        {
            txtCategoria.SelectAll();
        }

        private void txtCategoria_MouseClick(object sender, MouseEventArgs e)
        {
            txtCategoria.SelectAll();
        }

        private void txtCategoria_MouseLeave(object sender, EventArgs e)
        {
            if (txtCategoria.Text == "")
            {
                txtCategoria.Text = "Categoría";
                txtCategoria.ForeColor = Color.Silver;
            }
            if (txtCategoria.Text != "Categoría")
                txtCategoria.ForeColor = Color.Black;
        }

        private void txtID_Enter(object sender, EventArgs e)
        {
            txtID.SelectAll();
        }

        private void txtID_MouseClick(object sender, MouseEventArgs e)
        {
            txtID.SelectAll();
        }

        private void txtID_MouseLeave(object sender, EventArgs e)
        {
            if (txtID.Text == "")
            {
                txtID.Text = "ID";
                txtID.ForeColor = Color.Silver;
            }
            if (txtID.Text != "ID")
                txtID.ForeColor = Color.Black;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            //BOTÓN PARA GUARDAR LOS DATOS
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            //BOTÓN PARA EDITAR LOS CAMPOS
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            //BOTON PARA BORRAR UN REGISTRO
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            //BOTÓN PARA BUSCAR UN REGISTRO
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            //BOTÓN PARA SALIR AL MAIN
        }
    }
}
